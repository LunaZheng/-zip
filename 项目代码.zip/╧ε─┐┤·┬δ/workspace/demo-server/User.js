//module.exports  = {
//  userName:"Jack",
//  sayHello: function () {
//      return 'Hello';
//  }
//}

exports.userName = "Tom";
exports.sayHello = function () {
  return 'World';
}
